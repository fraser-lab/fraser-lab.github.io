---
title: "Late acquisition of mitochondria by a host with chimaeric prokaryotic ancestry"
authors: "**Pittis AA**, Gabaldón T"
journal: "Nature"
year: 2016
link: https://doi.org/10.1038/nature16941
---
